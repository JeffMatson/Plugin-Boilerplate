/**
 * scripts.js
 */